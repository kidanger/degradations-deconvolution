Dataset for the paper Modeling Realistic Degradations for Non-Blind Deconvolution
Authors: Jérémy Anger Mauricio Delbracio Gabriele Facciolo
Projet webpage: https://kidanger.github.io/degradations-deconvolution/

Warning: since we evaluate robustness of the methods against quantization, the images are stored as floats in TIFF files.
Moreover, the images are stored in non-linear space between 0 and 255. Apply a gamma of 1/2.2 to get back to linear space after changing the dynamic to 0-1.

Each folder contains the groundtruth image with its kernel and the simulated blurry image.

